%%8.7
help image
help colormap
help ColorSpec