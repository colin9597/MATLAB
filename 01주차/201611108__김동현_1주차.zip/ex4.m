%%4.3
99
39.24
-0.0075
1.35e-24
0.2E-5
12.0e44
z=2-5i
zz=3+2j

%%4.4
x=32.75
format short
x
format long
x
format long
z
format short e
x
format long e
x
format short

%%4.5
V = [6:-0.3:3]

%%4.6
M = [1:4; 1 4 9 16; 0.5 1.0 4.5 -8]

%%4.7
C = A .* B          
D = A ./ B

%%4.8
x1 = 4, y1=3, z1=4
x2=5; y2=5; z2=6
a=x1+y1+z1
b=x1+y1...
    +z1
c=x2+y2+z2
d=x2+y2...
    +z2

%%4.9
m=5
A * m
A + m
A - m
A / m
A ^ m

%%4.10
A(2,1)              % 2�� 1�� element
A(:,1)              % 1�� elements